# Onboarding to GKOP - Atlas

## ServiceNow/Ansible Tower integration  

This project is using the ServiceNow/Ansible Tower integration from [IFT3 (If-This-Then-That)](https://github.worldpay.com/robops/ansible-tower-ifttt)

to generate a form in ServiceNow, creates a workflow (Ansible Tower project and job) that:

- retreives this repository

- triggers a job that runs the playbook.yml ansible playbook using input variables passed in form

- playbook.yml generates Pull Requests for ATLAS, using the form variables

Any changes to configuration.yml will require a project reinstall. IFT3 Team has the required permissions to reload the form.

## Prerequisites
1. Ansible 2.9.0 or higher

2. Python with sdcclient and sys modules installed

3. Access to [Ansible Tower development instance](https://10.240.25.48/) used as Staging - access provided by IT3 with local credentials

4. Access to [ServiceNow development instance](https://atyourserviceportaldev1.service-now.com/supportall) -  e/lc credentials

5. In progress: GitHub authentication - Credentials - Hashicorp/Ansible


## Environment

The variables sets have different scopes (Local/Dev and Staging/Prod) due to form vars usage using the ```local: true``` flag. 

When running the main.yml playbook from local, you need
to use --extra-vars:

```bash
ansible-playbook playbook.yml -e @vars/test.yml
```

### This Ansible playbook automates all steps needed to raise a PR to Atlas repository to create namespace(s)

  - Clones and updates Atlas fork repository, creates new team branch and uploads changes to the remote fork
  - Installs pre-commit for identifying simple issues before submission to code review
  - Creates namespace manifests with default Quotas, Limits and NetworkPolicy
  - Creates one ServiceAccount per team that will be used in all the team namespaces
  - Creates Rolebinding manifests that map the team AD Groups and ServiceAccount to the GKOP `project-admin` and `project-read-only` ClusterRole
  - Syncs team AD Groups with GKOP
  - Creates a team in Sysdig and Sysdig Secure and adds the Technical Owner as a `team manager` and `service manager` respectively.

## Onboard new tenant

### Single tenant

1. Create file vars tenant-name.yml similar to the others. All info should be available on the onboarding form
2. Run the playbook, this will create a branch on the forked repo with the added files

```bash
ansible-playbook -i hosts playbook.yml -e atlas_sync=True -e separate_ldap=False -e "@vars/fxt-narwhals.yml" 
```

> You need to pass the `-e atlas_sync=True` parameter to update the fork

3. Raise the PR from Docet fork, branch tenant-name to Atlas/kosmos

### Multiple tenants

1. Create all the files vars/tenant-name.yml similar to the others. All info should be available on the onboarding form.
2. Run the playbook with the 'separate_ldap=True' extra variable for each tenant var file. This should avoid conflicts when merging multiple onboardings in a fow.

```bash
ansible-playbook -i hosts playbook.yml -e atlas_sync=True -e separate_ldap=True -e "@vars/fxt-narwhals.yml" 

```
> You need to pass the `-e atlas_sync=True` parameter to update the fork

3. Raise a PR from Docet for branch ldapsync to Atlas/kosmos. This should have all the ldap sync file changes for all tenants.
4. Raise the PRs from Docet fork, for each branch with a tenant-name to Atlas/kosmos.

## Files

### 1. configuration.yml - describes the form used by IFT3 integration:

- AT instance environment (and the corresponding credentials - Test/Prod)

### 2. playbook.yml

- runs all the tasks using the set of variables based on scope (local or Ansible Tower)

### 3.Variable Files

3.1 vars/default_vars.yml

```yaml
repo: kosmos
git_user: {{ request_form_vars.form_git_user | lower | regex_replace('(?!-|,)(\\W|\\s)', '') | regex_replace('_', '-') }}
feature: "{{ request_form_vars.form_feature }}"
team_name: "{{ request_form_vars.form_team_name | lower | regex_replace('(?!-|,)(\\W|\\s)', '') | regex_replace('_', '-') }}"
team_ad_name: "{{ request_form_vars.form_team_ad_name | lower | regex_replace('(?!-|,)(\\W|\\s)', '') | regex_replace('_', '-') }}"
team_email: "{{ request_form_vars.form_contact_email }}" 
snow_group: "{{ request_form_vars.form_snow_group }}"
scid: "{{ request_form_vars.form_scid }}"
buc: "{{ request_form_vars.form_buc }}"
rbu: "{{ request_form_vars.form_rbu }}" 
namespace: 
  - "{{ (request_form_vars.form_namespace | lower | regex_replace('(?!-|,)(\\W|\\s)', '') | regex_replace('_', '-')).split(',') }}"
```
Refer sample file: * [Tenant sample](/vars/tenant-sample.yml)


| Variable | Description
| --- | --- |
| `team_name` | Tenant Team Name <br> ( *make sure to not have underscores and only dashes as the name, for example team-gravity and not team_gravity* ) |
| `contact_email` | Email address of the requester, in case there will be issues with the request
| `feature`| You can choose in which GKOP cluster the namespace will be created <br> **staging** - namespace will be created only in the staging clusters <br> **prod** - namespace will be created in both staging and production clusters <br> **global** - namespace will be created in both production and staging clusters
| `namespace` | Namespace Name ( *can have multpile values if more than once namespce is required* ) |
| `repo` | Repository Name (e.g: kosmos) |
| `token` | The github token |
| `sysdig_token` | The sysdig token |
| `sysdig_secure_token` | The sysdig secure token |
| `sysdig_technical_owner` | The person that is going to be responsible with adding people in Sysdig and Sysdig secure |
| `sysdig_scope` | The regex that will help the user find his namespaces in Sysdig |


* 3.2 vars/default_vars_local.yml - same as vars/default_vars.yml but for local dev and testing

* 3.3 vars/test_local.yml - template for dynamic vars local dev and testing environment

You will need to make a copy (ie. test.yml) and set your values. Do not push this copy to GitHub
### 4. git_clone.yml

- clones the repositories found in vars/default_vars<>.yaml dictionary repo_name and adds the upstreams

### 5. ldap-sync.yml

- creates Rolebinding manifests that map the team AD Groups and ServiceAccount to the GKOP project-admin and project-read-only ClusterRole

### 6. namespace.yml

- creates namespace manifests with default Quotas, Limits and NetworkPolicy

### 7. git_push.yml

- uploads changes to the remote fork

### 8. templates/sysdig/onboard_user_team.py

- creates a team in Sysdig and Sysdig Secure and adds the Technical Owner as a team manager and service manager respectively.


## Author Information

Andrei Popescu - DevOps Engineer - andrei.popescu2@fisglobal.com

Cristian Preda - DevOps Engineer - cristian.preda@fisglobal.com

Ajerthan Sivayoganathan - DevOps Engineer - ajerthan.sivayoganathan@fisglobal.com