#!/usr/bin/env python

##################################################################################
## Onboards user/team & assigns user to team.
##################################################################################
## Maintainer: Gravity Team
## Status: WIP
## Usage: %s <monitor-token> <secure-token> team-name user-name scope
##  E.g  python3 onboard_user_team.py x x gravity gravity@fisglobal.com gravity-
##################################################################################

# Generic/Built-in
import sys

from sdcclient import SdcClient


# Parse arguments
if len(sys.argv) != 6:
    print(('usage: %s <sysdig-token> team-name user-name' % sys.argv[0]))
    print('You can find your token at https://app.sysdigcloud.com/#/settings/user')
    sys.exit(1)

sdcm_token = sys.argv[1]
sdcs_token = sys.argv[2]
team_name = sys.argv[3]
user_email = sys.argv[4].lower()
team_name_secure = team_name + '-secure'
scope = sys.argv[5].lower()
scope_filter = 'container.label.io.kubernetes.pod.namespace starts with ' + '"' + scope + '"' 
print (scope_filter)

# Instantiate the SDC client
sdclientm = SdcClient(sdcm_token, sdc_url='https://app.sysdigcloud.com')
sdclients = SdcClient(sdcs_token, sdc_url='https://secure.sysdig.com')

def create_user_invite(user_email, platform, client):
    """    
    Creates a new User
    """
    print(('Trying to invite a user to Sysdig ' +  platform + ':', user_email))
    ok, res = client.create_user_invite(user_email)
    if not ok:
        if res == 'user ' + user_email + ' already exists':
            print(('User creation failed in Sysig ' +  platform + ' because', user_email, 'already exists. Continuing.'))
        else:
            print(('User creation failed in Sysig ' +  platform + ':', res, '. Exiting.'))
            # sys.exit(1)
    else:
        print('User creation succeeded in Sysig ' +  platform)


def create_team(team_name, platform, client):
    """
    Creates a new Team
    """
    print(('Now trying to create a team within Sysdig ' +  platform + ' with name:', team_name))
    ok, res = client.create_team(team_name)
    if not ok:
        print(('Team creation failed within Sysdig ' +  platform + ':', res, '. Exiting.'))
    else:
        print(('Team creation succeeded within Sysdig ' +  platform + '.'))


def assign_user_to_team(user_email, team_name, platform, role, client):
    """
    Add new or update existing memberships
    """
    ok, res = client.save_memberships(team_name, {user_email: role})
    if not ok:
        print(('-- Unable to modify membership for ', user_email, ' to ', team_name, ' in Sysdig ' + platform + ' due to: ', res,
                '. Exiting.'))
    else:
        print(('User assigned to Team as ' + role + ' in Sysdig ' + platform + '.', res))
    pass


def add_scope_to_team(client, team_name, scope):
    """
    Adds visibility scope to a team
    """
    ok, res = client.edit_team(team_name, filter=scope, show='container')
    if not ok:
        print('Addition of scope failled due to ', res)
    else:
        print('Adding scope visibility sucessful', res)
    pass

# main script

create_user_invite(user_email, 'Monitor', sdclientm)
create_user_invite(user_email, 'Secure', sdclients)

create_team(team_name, 'Monitor', sdclientm)
create_team(team_name_secure, 'Secure', sdclients)

assign_user_to_team(user_email, team_name, 'Monitor', 'ROLE_TEAM_MANAGER', sdclientm)
assign_user_to_team(user_email, team_name_secure, 'Secure','ROLE_TEAM_SERVICE_MANAGER', sdclients)

add_scope_to_team(sdclientm, team_name, scope_filter)
add_scope_to_team(sdclients, team_name_secure, scope_filter)